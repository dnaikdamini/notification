package com.example.dell.proj5;

import android.app.Notification;
import android.app.NotificationManager;


import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.TaskStackBuilder;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import javax.xml.transform.Result;

public class MainActivity extends AppCompatActivity {
    Button b1, b2, b3;
    NotificationCompat.Builder notification;


    Intent resultIntent;
    TaskStackBuilder stackBuilder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 = (Button) findViewById(R.id.button);
        b2 = (Button) findViewById(R.id.button2);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              /* String ns=Context.NOTIFICATION_SERVICE;
                Intent notificationIntent=new Intent();
                PendingIntent  contentIntent=PendingIntent.getActivity(MainActivity.this, 0,notificationIntent,0);
                NotificationManager   notificationManager=(NotificationManager)getSystemService(ns);
                Notification notification=new Notification.Builder(MainActivity.this)
                        .setTicker("Message")
                        .setContentTitle("new message")
                        .setContentText("hello!you have a new message")

                        .setContentIntent(contentIntent).getNotification();
                notification.flags=Notification.FLAG_AUTO_CANCEL;
                notificationManager.notify(0,notification);

*/
                NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(MainActivity.this,"2");
                mBuilder.setSmallIcon(R.drawable.ic_launcher_background);
                mBuilder.setContentTitle("Notification Alert, Click Me!");
                mBuilder.setContentText("Hi, This is Android Notification Detail!");
                NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

// notificationID allows you to update the notification later on.
                mNotificationManager.notify(1, mBuilder.build());
            }


           /* protected void startNotification() {
                // TODO Auto-generated method stub
                //Creating Notification Builder
                notification = new NotificationCompat.Builder(MainActivity.this);
                //Title for Notification
                notification.setContentTitle("Learn2Crack Updates");
                //Message in the Notification
                notification.setContentText("New Post on Android Notification.");
                //Alert shown when Notification is received
                notification.setTicker("New Message Alert!");
                //Icon to be set on Notification
                notification.setSmallIcon(R.drawable.star);
                //Creating new Stack Builder
                stackBuilder = TaskStackBuilder.create(MainActivity.this);
                stackBuilder.addParentStack(Result.class);
                //Intent which is opened when notification is clicked
                resultIntent = new Intent(MainActivity.this, Result.class);
                stackBuilder.addNextIntent(resultIntent);
                contentIntent =  stackBuilder.getPendingIntent(0,PendingIntent.FLAG_UPDATE_CURRENT);
                notification.setContentIntent(contentIntent);
                notificationManager =(NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                notificationManager.notify(0, notification.build());*/


        });




        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"my name is xyz",Toast.LENGTH_LONG).show();
            }
        });

    }
        /*private void startNotification() {
            NotificationCompat.Builder builder =
                    new NotificationCompat.Builder(MainActivity.this).setSmallIcon(R.drawable.star)
                            .setContentTitle("Notifications Example")
                            .setContentText("This is a test notification");
            stackBuilder=TaskStackBuilder.create(MainActivity.this);
            stackBuilder.addParentStack(Result.class);
            resultIntent=
                    Intent notificationIntent = new Intent(this, MainActivity.class);
            PendingIntent contentIntent = PendingIntent.getActivity(this, 0, notificationIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT);
            builder.setContentIntent(contentIntent);

            // Add as notification
            NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            manager.notify(0, builder.build());
        }
    }*/



    public void open(View view) {
        b3=(Button)findViewById(R.id.button3);
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Are you sure,You wanted to make decision");
        alertDialogBuilder.setPositiveButton("yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface arg0, int arg1) {
                Toast.makeText(MainActivity.this, "You clicked yes button", Toast.LENGTH_LONG).show();
            }
        });

        alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override

            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });

        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }
}
